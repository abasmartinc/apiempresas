<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_WooCommerce {

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_script']);
        add_action('wp_ajax_apiempresas_search_company', [$this, 'ajax_search_company']);
        add_action('wp_ajax_nopriv_apiempresas_search_company', [$this, 'ajax_search_company']);
    }

    public function enqueue_checkout_script() {
        // Solo cargar en la página de checkout
        if (!is_checkout()) {
            return;
        }

        $apiKey = get_option('apiempresas_api_key');
        if (empty($apiKey)) {
            return;
        }

        wp_enqueue_script('apiempresas-woo-js', APIEMPRESAS_PLUGIN_URL . 'assets/js/checkout.js', [], '1.0.0', true);
        
        wp_localize_script('apiempresas-woo-js', 'apiempresasSettings', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('apiempresas_checkout_nonce')
        ]);
    }

    public function ajax_search_company() {
        check_ajax_referer('apiempresas_checkout_nonce', 'nonce');

        $cif = isset($_POST['cif']) ? sanitize_text_field($_POST['cif']) : '';
        if (empty($cif)) {
            wp_send_json_error('CIF is required');
        }

        $apiKey = get_option('apiempresas_api_key');
        if (empty($apiKey)) {
            wp_send_json_error('API Key not configured');
        }

        $apiUrl = 'https://apiempresas.es/api/v1/companies?cif=' . urlencode($cif);

        $response = wp_remote_get($apiUrl, [
            'headers' => [
                'X-API-KEY' => $apiKey,
                'Accept'    => 'application/json'
            ],
            'timeout' => 15
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data)) {
            wp_send_json_error('Invalid response from API');
        }

        wp_send_json($data);
    }
}
