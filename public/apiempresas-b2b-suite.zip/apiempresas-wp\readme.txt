=== APIEmpresas B2B Suite ===
Contributors: apiempresas
Tags: woocommerce, b2b, empresas, cif, autofill
Requires at least: 5.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integra el poder de APIEmpresas en tu WordPress. Buscador de empresas B2B y autocompletado de facturación para WooCommerce.

== Description ==

El plugin oficial de **APIEmpresas** aporta inteligencia y automatización a tu sitio WordPress B2B.

Con esta suite podrás:
* **Autocompletado B2B en WooCommerce:** Añade un campo inteligente al finalizar la compra. Cuando tu cliente corporativo introduce su CIF, el plugin se conecta a la base de datos de APIEmpresas y autocompleta instantáneamente todos los datos de facturación (Nombre de empresa, Dirección, Provincia, Código Postal, etc.). Evita errores humanos, carritos abandonados por pereza y agiliza el proceso de compra.
* **Buscador Universal (Shortcode):** Utiliza el shortcode `[apiempresas_buscador]` en cualquier página, post o widget de tu web. Crea un buscador B2B donde tus usuarios pueden consultar datos públicos, estado y sector de cualquier empresa de España con tan solo escribir su CIF.
* **Dashboard Analítico:** Controla en tiempo real desde tu panel de WordPress las estadísticas de consumo de tu API Key y el historial de las últimas empresas buscadas por tus clientes.

Todo de forma segura (la API Key nunca se expone en el navegador) y optimizado para una latencia mínima.

== Installation ==

1. Sube la carpeta del plugin al directorio `/wp-content/plugins/` o instálalo directamente desde la pantalla de plugins de WordPress.
2. Activa el plugin a través de la pantalla 'Plugins' en WordPress.
3. Ve a **Ajustes > APIEmpresas** en el menú lateral.
4. Introduce tu API Key (puedes obtenerla gratis en [apiempresas.es](https://apiempresas.es)).
5. ¡Listo! El autocompletado de WooCommerce se activará solo. Para usar el buscador, pega el shortcode `[apiempresas_buscador]` donde necesites.

== Frequently Asked Questions ==

= ¿Necesito pagar para usar este plugin? =
El plugin es gratuito, pero requiere una API Key de APIEmpresas. Existen planes gratuitos (Free) para empezar y planes Pro para tiendas con alto volumen.

= ¿Expone el plugin mi API Key al público? =
No. Todas las peticiones se enrutan de forma segura a través del backend de tu servidor WordPress (vía AJAX). Tu clave nunca viaja al navegador del cliente.

== Screenshots ==

1. Panel de estadísticas y configuración en el backend.
2. Buscador en acción mediante shortcode.
3. Autocompletado B2B en el checkout de WooCommerce.

== Changelog ==

= 1.0.0 =
* Lanzamiento inicial de la Suite APIEmpresas.
* Integración con WooCommerce y shortcode de buscador público.
