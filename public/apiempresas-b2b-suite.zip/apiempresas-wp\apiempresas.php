<?php
/**
 * Plugin Name: APIEmpresas B2B Suite
 * Description: Integra el poder de APIEmpresas en tu WordPress. Incluye buscador de empresas mediante Shortcode y autocompletado de facturación para WooCommerce B2B.
 * Version: 1.0.0
 * Author: APIEmpresas
 * Author URI: https://apiempresas.es
 * Text Domain: apiempresas-b2b-suite
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('APIEMPRESAS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('APIEMPRESAS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Includes
require_once APIEMPRESAS_PLUGIN_DIR . 'includes/class-apiempresas-admin.php';
require_once APIEMPRESAS_PLUGIN_DIR . 'includes/class-apiempresas-woocommerce.php';
require_once APIEMPRESAS_PLUGIN_DIR . 'includes/class-apiempresas-shortcodes.php';

// Initialize
function apiempresas_plugin_init() {
    new APIEmpresas_Admin();
    
    // Solo inicializar Woo si WooCommerce está activo
    if (class_exists('WooCommerce')) {
        new APIEmpresas_WooCommerce();
    }
    
    new APIEmpresas_Shortcodes();
}
add_action('plugins_loaded', 'apiempresas_plugin_init');
