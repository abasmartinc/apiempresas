<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_plugin_page']);
        add_action('admin_init', [$this, 'page_init']);
    }

    public function add_plugin_page() {
        // Añadir como item de menú principal
        add_menu_page(
            'Configuración APIEmpresas', 
            'APIEmpresas', 
            'manage_options', 
            'apiempresas-settings', 
            [$this, 'create_admin_page'],
            'dashicons-building', // Icono de edificio/empresa
            30 // Posición en el menú
        );

        // Añadir submenú de Estadísticas
        add_submenu_page(
            'apiempresas-settings',
            'Estadísticas de Uso',
            'Estadísticas',
            'manage_options',
            'apiempresas-stats',
            [$this, 'create_stats_page']
        );
    }

    public function create_stats_page() {
        $apiKey = get_option('apiempresas_api_key');
        
        // Estilos para la página de estadísticas
        ?>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
            
            .apiempresas-wrap {
                margin: 20px 20px 20px 0;
                font-family: 'Inter', sans-serif;
                color: #1e293b;
            }
            .apiempresas-super-card {
                background: #ffffff;
                border-radius: 24px;
                box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.02);
                overflow: hidden;
            }
            .apiempresas-hero {
                background: linear-gradient(135deg, #081026 0%, #15295c 100%);
                padding: 60px 50px;
                color: white;
                position: relative;
                overflow: hidden;
            }
            .apiempresas-hero::before {
                content: '';
                position: absolute;
                top: -50%; left: -50%; width: 200%; height: 200%;
                background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 60%);
                animation: apiPulse 15s infinite linear;
            }
            .apiempresas-hero-content {
                position: relative;
                z-index: 10;
                display: flex;
                align-items: center;
                gap: 30px;
            }
            .apiempresas-hero-icon {
                width: 80px;
                height: 80px;
                background: rgba(255,255,255,0.15);
                border-radius: 24px;
                backdrop-filter: blur(10px);
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid rgba(255,255,255,0.2);
                box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            }
            .apiempresas-hero-icon .dashicons {
                font-size: 40px;
                width: 40px;
                height: 40px;
                color: white;
            }
            .apiempresas-hero-text h1 {
                font-size: 42px;
                font-weight: 800;
                margin: 0 0 10px 0;
                color: white;
                letter-spacing: -0.02em;
                line-height: 1.1;
            }
            .apiempresas-hero-text p {
                font-size: 18px;
                margin: 0;
                opacity: 0.9;
                font-weight: 400;
            }
            .apiempresas-body {
                padding: 50px;
                background: #f8fafc;
            }
            .apiempresas-stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
                gap: 24px;
                margin-bottom: 40px;
            }
            .apiempresas-stat-card {
                background: white;
                border: 1px solid #e2e8f0;
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            .apiempresas-stat-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 12px 20px -8px rgba(0,0,0,0.08);
            }
            .apiempresas-stat-card h3 {
                margin: 0 0 15px 0;
                color: #64748b;
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                font-weight: 700;
            }
            .apiempresas-stat-card .value {
                font-size: 48px;
                font-weight: 800;
                color: #0f172a;
                letter-spacing: -0.02em;
            }
            .apiempresas-cta-card {
                background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%);
                border-radius: 20px;
                padding: 40px;
                color: white;
                margin-bottom: 40px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.4);
                position: relative;
                overflow: hidden;
            }
            .apiempresas-cta-card::after {
                content: '';
                position: absolute;
                top: 0; right: 0; width: 50%; height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255,255,255,0.05));
                transform: skewX(-20deg);
            }
            .apiempresas-cta-card-content {
                position: relative;
                z-index: 10;
            }
            .apiempresas-cta-card h2 {
                color: white;
                margin: 0 0 10px 0;
                font-size: 32px;
                font-weight: 800;
                letter-spacing: -0.02em;
            }
            .apiempresas-cta-card p {
                margin: 0;
                font-size: 18px;
                opacity: 0.9;
            }
            .apiempresas-btn-upgrade {
                background: #f59e0b;
                color: white;
                padding: 16px 32px;
                border-radius: 12px;
                text-decoration: none;
                font-weight: 700;
                font-size: 18px;
                transition: all 0.2s ease;
                position: relative;
                z-index: 10;
                box-shadow: 0 4px 15px rgba(245, 158, 11, 0.4);
            }
            .apiempresas-btn-upgrade:hover {
                background: #d97706;
                transform: scale(1.02);
                box-shadow: 0 8px 25px rgba(245, 158, 11, 0.6);
                color: white;
            }
            .apiempresas-history-wrapper {
                background: white;
                border-radius: 20px;
                border: 1px solid #e2e8f0;
                box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
                overflow: hidden;
            }
            .apiempresas-history-wrapper h2 {
                margin: 0;
                padding: 30px;
                font-size: 24px;
                font-weight: 700;
                color: #0f172a;
                border-bottom: 1px solid #e2e8f0;
                background: #f8fafc;
            }
            .apiempresas-history-table {
                width: 100%;
                border-collapse: collapse;
            }
            .apiempresas-history-table th, .apiempresas-history-table td {
                padding: 20px 30px;
                text-align: left;
                border-bottom: 1px solid #f1f5f9;
                font-size: 16px;
            }
            .apiempresas-history-table th {
                background: white;
                font-weight: 600;
                color: #64748b;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                font-size: 13px;
            }
            .apiempresas-history-table tr:last-child td {
                border-bottom: none;
            }
            .apiempresas-history-table tbody tr {
                transition: background-color 0.2s;
            }
            .apiempresas-history-table tbody tr:hover {
                background-color: #f8fafc;
            }
            .apiempresas-progress-bar {
                width: 100%;
                height: 12px;
                background: #f1f5f9;
                border-radius: 6px;
                margin-top: 20px;
                overflow: hidden;
            }
            .apiempresas-progress-fill {
                height: 100%;
                background: linear-gradient(90deg, #10b981 0%, #34d399 100%);
                border-radius: 6px;
                transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .apiempresas-progress-fill.warning {
                background: linear-gradient(90deg, #f59e0b 0%, #fbbf24 100%);
            }
            .apiempresas-progress-fill.danger {
                background: linear-gradient(90deg, #ef4444 0%, #f87171 100%);
            }
            .cif-badge {
                background: #f1f5f9;
                padding: 6px 12px;
                border-radius: 8px;
                font-family: monospace;
                font-weight: 600;
                color: #334155;
            }
        </style>

        <div class="wrap apiempresas-wrap">
            <div class="apiempresas-super-card">
                <div class="apiempresas-hero">
                    <div class="apiempresas-hero-content">
                        <div class="apiempresas-hero-icon">
                            <span class="dashicons dashicons-chart-area"></span>
                        </div>
                        <div class="apiempresas-hero-text">
                            <h1>Estadísticas de Consumo</h1>
                            <p>Monitorea el uso de tu API y el historial de búsquedas en tiempo real.</p>
                        </div>
                    </div>
                </div>

                <div class="apiempresas-body">
                    <?php
                    if (empty($apiKey)) {
                        echo '<div class="apiempresas-stat-card"><p>Por favor, configura tu API Key primero en la pestaña de Configuración.</p></div></div></div>';
                        return;
                    }

                    $response = wp_remote_get('https://apiempresas.es/api/v1/usage', [
                        'headers' => ['X-API-KEY' => $apiKey],
                        'timeout' => 15
                    ]);

                    if (is_wp_error($response)) {
                        echo '<div class="apiempresas-stat-card"><p>Error de conexión con APIEmpresas: ' . esc_html($response->get_error_message()) . '</p></div></div></div>';
                        return;
                    }

                    $body = wp_remote_retrieve_body($response);
                    $data = json_decode($body, true);

                    if (!$data || !isset($data['success']) || !$data['success']) {
                        $errorMsg = isset($data['error']) ? $data['error'] : 'Clave API inválida o error desconocido.';
                        echo '<div class="apiempresas-stat-card"><p>Error: ' . esc_html($errorMsg) . '</p></div></div></div>';
                        return;
                    }

                    $stats = $data['data']['stats'];
                    $history = $data['data']['history'];
                    
                    $planName = isset($stats['plan_name']) ? $stats['plan_name'] : 'Free';
                    $planSlug = isset($stats['plan_slug']) ? $stats['plan_slug'] : 'free';
                    $quota = (int)$stats['monthly_quota'];
                    $remaining = (int)$stats['remaining_calls'];

                    if ($planSlug === 'free' && isset($stats['total_queries'])) {
                        $consumed = (int)$stats['total_queries'];
                        $statsTitle = 'Consultas Totales';
                    } else {
                        $consumed = (int)$stats['monthly_queries'];
                        $statsTitle = 'Llamadas Consumidas';
                    }

                    // Forzar que el historial visualmente coincida con el KPI (para evitar confusiones)
                    if (count($history) > $consumed && $consumed > 0) {
                        $history = array_slice($history, 0, $consumed);
                    } elseif ($consumed === 0) {
                        $history = [];
                    }

                    $percent = $quota > 0 ? ($consumed / $quota) * 100 : 100;
                    if ($percent > 100) $percent = 100;
                    
                    $progressClass = '';
                    if ($percent >= 90) $progressClass = 'danger';
                    elseif ($percent >= 70) $progressClass = 'warning';

                    // Upsell CTA
                    if ($planSlug === 'free' || $percent >= 80) {
                        ?>
                        <div class="apiempresas-cta-card">
                            <div class="apiempresas-cta-card-content">
                                <h2>¡Desbloquea el potencial completo!</h2>
                                <p>Estás utilizando el <strong><?php echo esc_html($planName); ?></strong>. Da el salto a un plan Pro para peticiones ilimitadas y datos premium.</p>
                            </div>
                            <a href="https://apiempresas.es/api-empresas" target="_blank" class="apiempresas-btn-upgrade">Explorar Planes Pro</a>
                        </div>
                        <?php
                    }
                    ?>

                    <div class="apiempresas-stats-grid">
                        <div class="apiempresas-stat-card">
                            <h3>Plan Actual</h3>
                            <div class="value" style="font-size: 36px;"><?php echo esc_html($planName); ?></div>
                        </div>
                        <div class="apiempresas-stat-card">
                            <h3><?php echo esc_html($statsTitle); ?></h3>
                            <div class="value"><?php echo number_format($consumed, 0, ',', '.'); ?> <span style="font-size: 20px; color: #94a3b8; font-weight: 500;">/ <?php echo number_format($quota, 0, ',', '.'); ?></span></div>
                            <div class="apiempresas-progress-bar">
                                <div class="apiempresas-progress-fill <?php echo $progressClass; ?>" style="width: <?php echo $percent; ?>%;"></div>
                            </div>
                        </div>
                        <div class="apiempresas-stat-card">
                            <h3>Llamadas Restantes</h3>
                            <div class="value" style="color: <?php echo $remaining <= 50 ? '#ef4444' : '#10b981'; ?>;">
                                <?php echo number_format($remaining, 0, ',', '.'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="apiempresas-history-wrapper">
                        <h2>Últimas Búsquedas B2B</h2>
                        <?php if (empty($history)) : ?>
                            <div style="padding: 30px;"><p style="margin:0; color:#64748b;">Aún no has realizado ninguna consulta.</p></div>
                        <?php else : ?>
                            <table class="apiempresas-history-table">
                                <thead>
                                    <tr>
                                        <th>CIF</th>
                                        <th>Razón Social</th>
                                        <th>Provincia</th>
                                        <th>Sector (CNAE)</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($history as $emp) : 
                                        $isFound = isset($emp['found']) ? $emp['found'] : true;
                                    ?>
                                        <tr>
                                            <td><span class="cif-badge" style="display:inline-block; max-width:180px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; vertical-align:middle;" title="<?php echo esc_attr($emp['cif']); ?>"><?php echo esc_html($emp['cif']); ?></span></td>
                                            <td style="font-weight: 500; color: <?php echo $isFound ? '#0f172a' : '#94a3b8'; ?>;"><?php echo esc_html($emp['name']); ?></td>
                                            <td style="color: <?php echo $isFound ? '#475569' : '#cbd5e1'; ?>;"><?php echo esc_html($emp['province']); ?></td>
                                            <td style="color: <?php echo $isFound ? '#64748b' : '#cbd5e1'; ?>;"><?php echo esc_html($emp['cnae_label']); ?></td>
                                            <td>
                                                <?php if ($isFound) : ?>
                                                    <span style="display:inline-flex; align-items:center; gap:4px; background:#dcfce7; color:#166534; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; white-space:nowrap;">
                                                        <span class="dashicons dashicons-yes-alt" style="font-size:16px; width:16px; height:16px; margin-top:2px;"></span> Encontrada
                                                    </span>
                                                <?php else : ?>
                                                    <span style="display:inline-flex; align-items:center; gap:4px; background:#fee2e2; color:#991b1b; padding:4px 10px; border-radius:20px; font-size:12px; font-weight:600; white-space:nowrap;">
                                                        <span class="dashicons dashicons-dismiss" style="font-size:16px; width:16px; height:16px; margin-top:2px;"></span> No encontrada
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
        <?php
    }

    public function create_admin_page() {
        ?>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
            
            .apiempresas-wrap {
                margin: 20px 20px 20px 0;
                font-family: 'Inter', sans-serif;
                color: #1e293b;
            }
            .apiempresas-super-card {
                background: #ffffff;
                border-radius: 24px;
                box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05), 0 0 0 1px rgba(0,0,0,0.02);
                overflow: hidden;
            }
            .apiempresas-hero {
                background: linear-gradient(135deg, #081026 0%, #15295c 100%);
                padding: 60px 50px;
                color: white;
                position: relative;
                overflow: hidden;
            }
            .apiempresas-hero::before {
                content: '';
                position: absolute;
                top: -50%; left: -50%; width: 200%; height: 200%;
                background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 60%);
                animation: apiPulse 15s infinite linear;
            }
            @keyframes apiPulse {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            .apiempresas-hero-content {
                position: relative;
                z-index: 10;
                display: flex;
                align-items: center;
                gap: 30px;
            }
            .apiempresas-hero-icon {
                width: 80px;
                height: 80px;
                background: rgba(255,255,255,0.15);
                border-radius: 24px;
                backdrop-filter: blur(10px);
                display: flex;
                align-items: center;
                justify-content: center;
                border: 1px solid rgba(255,255,255,0.2);
                box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1);
            }
            .apiempresas-hero-icon .dashicons {
                font-size: 40px;
                width: 40px;
                height: 40px;
                color: white;
            }
            .apiempresas-hero-text h1 {
                font-size: 42px;
                font-weight: 800;
                margin: 0 0 10px 0;
                color: white;
                letter-spacing: -0.02em;
                line-height: 1.1;
            }
            .apiempresas-hero-text p {
                font-size: 18px;
                margin: 0;
                opacity: 0.9;
                font-weight: 400;
                max-width: 600px;
            }
            .apiempresas-body {
                padding: 50px;
                background: #f8fafc;
            }
            .apiempresas-card {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 20px;
                padding: 40px;
                box-shadow: 0 4px 6px -1px rgba(0,0,0,0.02);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                margin-bottom: 30px;
            }
            .apiempresas-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 12px 20px -8px rgba(0,0,0,0.08);
            }
            .apiempresas-card h2 {
                margin-top: 0;
                font-size: 24px;
                font-weight: 700;
                color: #0f172a;
                border-bottom: 2px solid #f1f5f9;
                padding-bottom: 20px;
                margin-bottom: 30px;
            }
            .apiempresas-input-group label {
                display: block;
                font-weight: 600;
                margin-bottom: 12px;
                color: #334155;
                font-size: 16px;
            }
            .apiempresas-input-group input[type="password"] {
                width: 100%;
                max-width: 600px;
                padding: 16px 20px;
                border: 2px solid #cbd5e1;
                border-radius: 12px;
                font-size: 18px;
                transition: all 0.3s ease;
                box-shadow: inset 0 2px 4px 0 rgba(0,0,0,0.02);
            }
            .apiempresas-input-group input[type="password"]:focus {
                border-color: #0ea5e9;
                box-shadow: 0 0 0 4px rgba(14, 165, 233, 0.15);
                outline: none;
            }
            .apiempresas-desc {
                margin-top: 15px;
                font-size: 15px;
                color: #64748b;
            }
            .apiempresas-btn-primary {
                background: #1d4ed8;
                color: white;
                border: none;
                padding: 16px 32px;
                border-radius: 12px;
                font-size: 18px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s ease;
                display: inline-block;
                text-decoration: none;
                margin-top: 20px;
                box-shadow: 0 4px 15px rgba(29, 78, 216, 0.3);
            }
            .apiempresas-btn-primary:hover {
                background: #1e40af;
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(29, 78, 216, 0.4);
            }
            .apiempresas-features {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 24px;
            }
            .apiempresas-feature-box {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                padding: 30px;
                position: relative;
                overflow: hidden;
            }
            .apiempresas-feature-box::before {
                content: '';
                position: absolute;
                top: 0; left: 0; width: 4px; height: 100%;
                background: #0ea5e9;
            }
            .apiempresas-feature-box h3 {
                margin-top: 0;
                font-size: 20px;
                font-weight: 700;
                color: #0f172a;
                display: flex;
                align-items: center;
                gap: 12px;
                margin-bottom: 15px;
            }
            .apiempresas-feature-box h3 .dashicons {
                color: #0ea5e9;
                font-size: 24px;
                width: 24px; height: 24px;
            }
            .apiempresas-feature-box p {
                color: #64748b;
                font-size: 16px;
                line-height: 1.6;
                margin: 0;
            }
            .apiempresas-feature-box code {
                background: #f1f5f9;
                padding: 4px 8px;
                border-radius: 6px;
                color: #0f172a;
                font-weight: 600;
                font-size: 14px;
            }
            .apiempresas-notice {
                background: #ecfdf5;
                border: 1px solid #10b981;
                border-radius: 12px;
                padding: 20px;
                color: #065f46;
                font-weight: 500;
                margin-bottom: 30px;
                display: flex;
                align-items: center;
                gap: 12px;
            }
        </style>

        <div class="wrap apiempresas-wrap">
            <div class="apiempresas-super-card">
                <div class="apiempresas-hero">
                    <div class="apiempresas-hero-content">
                        <div class="apiempresas-hero-icon">
                            <span class="dashicons dashicons-building"></span>
                        </div>
                        <div class="apiempresas-hero-text">
                            <h1>APIEmpresas B2B Suite</h1>
                            <p>Convierte tu WordPress en una máquina de datos mercantiles oficiales.</p>
                        </div>
                    </div>
                </div>

                <div class="apiempresas-body">
                    <?php 
                    $apiKey = get_option('apiempresas_api_key');
                    if (empty($apiKey)) {
                        echo '<div class="apiempresas-notice" style="background:#fffbeb; border-color:#f59e0b; color:#b45309;"><span class="dashicons dashicons-info-outline" style="font-size:24px; width:24px; height:24px; color:#f59e0b;"></span> Aún no has configurado tu API Key. Introdúcela abajo para empezar.</div>';
                    } else {
                        $response = wp_remote_get('https://apiempresas.es/api/v1/usage', [
                            'headers' => ['X-API-KEY' => $apiKey],
                            'timeout' => 5
                        ]);

                        if (is_wp_error($response)) {
                            echo '<div class="apiempresas-notice" style="background:#fef2f2; border-color:#ef4444; color:#991b1b;"><span class="dashicons dashicons-warning" style="font-size:24px; width:24px; height:24px; color:#ef4444;"></span> Error de conexión con APIEmpresas: ' . esc_html($response->get_error_message()) . '</div>';
                        } else {
                            $code = wp_remote_retrieve_response_code($response);
                            if ($code !== 200) {
                                echo '<div class="apiempresas-notice" style="background:#fef2f2; border-color:#ef4444; color:#991b1b;"><span class="dashicons dashicons-warning" style="font-size:24px; width:24px; height:24px; color:#ef4444;"></span> <strong>Error:</strong> La API Key configurada parece ser inválida o ha expirado. Por favor, revísala.</div>';
                            } elseif (isset($_GET['settings-updated'])) {
                                echo '<div class="apiempresas-notice"><span class="dashicons dashicons-yes-alt" style="font-size: 24px; width: 24px; height: 24px;"></span> ¡Conexión establecida con éxito! Tu web ya está vinculada a APIEmpresas.</div>';
                            }
                        }
                    }
                    ?>

                    <div class="apiempresas-card">
                        <h2>Autenticación y Conexión</h2>
                        <form method="post" action="options.php">
                            <?php settings_fields('apiempresas_option_group'); ?>
                            
                            <div class="apiempresas-input-group">
                                <label for="apiempresas_api_key">Clave Secreta de API (API Key)</label>
                                <?php $apiKey = get_option('apiempresas_api_key'); ?>
                                <input type="password" id="apiempresas_api_key" name="apiempresas_api_key" value="<?php echo esc_attr($apiKey); ?>" placeholder="sk_live_..." />
                                <p class="apiempresas-desc">
                                    Consigue tu API Key gratuita registrándote en el portal de <a href="https://apiempresas.es/register" target="_blank" style="color: #0ea5e9; font-weight: 600; text-decoration: none;">APIEmpresas.es</a>.
                                </p>
                            </div>

                            <button type="submit" class="apiempresas-btn-primary">Guardar y Conectar</button>
                        </form>
                    </div>

                    <div class="apiempresas-card">
                        <h2>Módulos Activos</h2>
                        <div class="apiempresas-features">
                            <div class="apiempresas-feature-box">
                                <h3><span class="dashicons dashicons-search"></span> Buscador B2B</h3>
                                <p>Copia y pega el shortcode <code>[apiempresas_buscador]</code> 
                                <button type="button" id="apiempresas-copy-btn" class="button button-secondary button-small" style="margin-left:5px; vertical-align:middle; cursor:pointer;" title="Copiar shortcode"><span class="dashicons dashicons-admin-page" style="margin-top:3px; font-size:16px; width:16px; height:16px;"></span></button>
                                en cualquier página o post para habilitar el motor de búsqueda en vivo.</p>
                            </div>
                            <div class="apiempresas-feature-box">
                                <h3><span class="dashicons dashicons-cart"></span> Auto-Checkout (WooCommerce)</h3>
                                <p>Integración automática con WooCommerce activada. El plugin rellena los datos fiscales de tus clientes en el momento en que escriben su CIF.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const copyBtn = document.getElementById('apiempresas-copy-btn');
                if (copyBtn) {
                    copyBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        navigator.clipboard.writeText('[apiempresas_buscador]').then(function() {
                            const icon = copyBtn.querySelector('.dashicons');
                            icon.classList.remove('dashicons-admin-page');
                            icon.classList.add('dashicons-yes');
                            icon.style.color = '#10b981';
                            setTimeout(() => {
                                icon.classList.remove('dashicons-yes');
                                icon.classList.add('dashicons-admin-page');
                                icon.style.color = '';
                            }, 2000);
                        });
                    });
                }
            });
        </script>
        <?php
    }

    public function page_init() {
        register_setting(
            'apiempresas_option_group',
            'apiempresas_api_key',
            ['sanitize_callback' => 'sanitize_text_field']
        );
    }
}
