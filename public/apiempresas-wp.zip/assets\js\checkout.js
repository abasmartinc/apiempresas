document.addEventListener('DOMContentLoaded', function() {
    let typingTimer;
    const doneTypingInterval = 800; // ms
    
    // Función especial para actualizar valores en campos controlados por React (Gutenberg / Block Checkout)
    function setReactInputValue(inputElement, value) {
        if (!inputElement) return;
        
        let prototype = window.HTMLInputElement.prototype;
        if (inputElement.tagName === 'SELECT') {
            prototype = window.HTMLSelectElement.prototype;
        } else if (inputElement.tagName === 'TEXTAREA') {
            prototype = window.HTMLTextAreaElement.prototype;
        }
        
        // 1. Establecer el valor nativamente
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(prototype, "value").set;
        if (nativeInputValueSetter) {
            nativeInputValueSetter.call(inputElement, value);
        } else {
            inputElement.value = value;
        }
        
        // 2. Disparar eventos para que React y jQuery (WooCommerce clásico) se enteren
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        inputElement.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Usar "Event Delegation" para escuchar el input, ya que el Block Checkout recarga el DOM dinámicamente
    document.body.addEventListener('input', function(e) {
        const target = e.target;
        if (!target || !target.tagName || target.tagName !== 'INPUT') return;
        
        // Buscar el label asociado al input (especialmente útil en el Block Checkout moderno)
        const labelEl = target.closest('div')?.querySelector('label');
        const labelText = labelEl ? labelEl.textContent.toLowerCase() : '';

        // Identificar si lo que se está escribiendo es el campo de Empresa o CIF
        const isCompanyField = target.id === 'billing_nif' 
                            || target.id === 'billing_vat' 
                            || target.id === 'billing_company'
                            || target.name === 'billing_company'
                            || (target.id && target.id.toLowerCase().includes('company'))
                            || labelText.includes('company')
                            || labelText.includes('empresa')
                            || labelText.includes('cif')
                            || labelText.includes('nif');

        if (!isCompanyField) return;

        clearTimeout(typingTimer);
        const val = target.value.trim();
        
        // Ejecutar búsqueda solo si tiene pinta de CIF/NIF (alfanumérico, sin espacios, 8-10 caracteres)
        // Esto evita que al autocompletar el "Nombre de la Empresa" (que tiene espacios) se lance otra petición
        const looksLikeCif = /^[a-zA-Z0-9]{8,10}$/.test(val);
        
        if (looksLikeCif) {
            typingTimer = setTimeout(() => searchCompany(val, target), doneTypingInterval);
        }
    });

    function searchCompany(query, triggerInput) {
        if (!apiempresasSettings || !apiempresasSettings.apiKey) {
            console.error("APIEmpresas: API Key no configurada.");
            return;
        }

        fetch(apiempresasSettings.apiUrl + encodeURIComponent(query), {
            headers: {
                'Authorization': 'Bearer ' + apiempresasSettings.apiKey,
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.name) {
                const emp = data.data;
                
                // 1. Reemplazar el CIF por el Nombre de la Empresa en el mismo campo
                if (!triggerInput.value || triggerInput.value.includes(query)) {
                    setReactInputValue(triggerInput, emp.name);
                }

                // 2. Autocompletar Dirección
                const address1 = document.getElementById('billing_address_1') || document.querySelector('input[id*="address-1"]') || document.querySelector('input[name="billing_address_1"]');
                if (address1 && emp.address) {
                    setReactInputValue(address1, emp.address);
                }

                // 3. Autocompletar Ciudad
                const city = document.getElementById('billing_city') || document.querySelector('input[id*="city"]') || document.querySelector('input[name="billing_city"]');
                if (city && emp.municipality) {
                    setReactInputValue(city, emp.municipality);
                }
                
                // Helper function para buscar campos por su Label (imprescindible para el Block Checkout)
                function findFieldByLabel(keywords) {
                    const labels = Array.from(document.querySelectorAll('label'));
                    for (let label of labels) {
                        const text = label.textContent.toLowerCase();
                        if (keywords.some(k => text.includes(k))) {
                            const forAttr = label.getAttribute('for');
                            if (forAttr) {
                                const el = document.getElementById(forAttr);
                                if (el) return el;
                            }
                            const child = label.closest('div').querySelector('input, select');
                            if (child) return child;
                        }
                    }
                    return null;
                }

                // 4. Autocompletar Provincia
                const state = document.getElementById('billing_state') 
                           || document.querySelector('select[name="billing_state"]') 
                           || findFieldByLabel(['province', 'provincia', 'state', 'estado', 'región']);
                           
                if (state && emp.province) {
                    // WooCommerce clásico usa códigos de provincia para España (ej: 'B' para Barcelona, 'C' para A Coruña)
                    const provincesMap = {
                        'a coruña': 'C', 'álava': 'VI', 'albacete': 'AB', 'alicante': 'A', 'almería': 'AL', 'asturias': 'O', 'ávila': 'AV', 'badajoz': 'BA', 'baleares': 'PM', 'barcelona': 'B', 'burgos': 'BU', 'cáceres': 'CC', 'cádiz': 'CA', 'cantabria': 'S', 'castellón': 'CS', 'ceuta': 'CE', 'ciudad real': 'CR', 'córdoba': 'CO', 'cuenca': 'CU', 'girona': 'GI', 'granada': 'GR', 'guadalajara': 'GU', 'gipuzkoa': 'SS', 'huelva': 'H', 'huesca': 'HU', 'jaén': 'J', 'la rioja': 'LO', 'las palmas': 'GC', 'león': 'LE', 'lleida': 'L', 'lugo': 'LU', 'madrid': 'M', 'málaga': 'MA', 'melilla': 'ML', 'murcia': 'MU', 'navarra': 'NA', 'ourense': 'OR', 'palencia': 'P', 'pontevedra': 'PO', 'salamanca': 'SA', 'segovia': 'SG', 'sevilla': 'SE', 'soria': 'SO', 'tarragona': 'T', 'santa cruz de tenerife': 'TF', 'teruel': 'TE', 'toledo': 'TO', 'valencia': 'V', 'valladolid': 'VA', 'bizkaia': 'BI', 'zamora': 'ZA', 'zaragoza': 'Z'
                    };
                    
                    let pName = emp.province.toLowerCase();
                    pName = pName.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
                    
                    let stateCode = '';
                    for (const [key, code] of Object.entries(provincesMap)) {
                        const cleanKey = key.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
                        if (cleanKey === pName || pName.includes(cleanKey)) {
                            stateCode = code;
                            break;
                        }
                    }

                    if (state.tagName === 'SELECT') {
                        // El checkout clásico espera el código de provincia (ej: "C")
                        setReactInputValue(state, stateCode || emp.province);
                    } else {
                        // El Block Checkout usa un Input de React (Combobox) que espera texto humano (ej: "A Coruña")
                        // Primero le pasamos el nombre humano de la provincia original
                        setReactInputValue(state, emp.province);
                        
                        // En el Block Checkout a veces hay que simular un Enter o desenfoque para que se fije
                        setTimeout(() => {
                            state.dispatchEvent(new Event('blur', { bubbles: true }));
                            state.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter' }));
                        }, 100);
                    }
                }

                // 5. Autocompletar Código Postal
                const postcode = document.getElementById('billing_postcode') || document.querySelector('input[id*="postcode"]') || document.querySelector('input[name="billing_postcode"]') || findFieldByLabel(['postal', 'postcode', 'código']);
                if (postcode && emp.zipcode) {
                    setReactInputValue(postcode, emp.zipcode);
                }
            }
        })
        .catch(err => {
            console.error('APIEmpresas Error:', err);
        });
    }
});
