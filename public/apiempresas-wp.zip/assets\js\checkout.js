document.addEventListener('DOMContentLoaded', function() {
    let typingTimer;
    const doneTypingInterval = 800; // ms
    
    // Función especial para actualizar valores en campos controlados por React (Gutenberg / Block Checkout)
    function setReactInputValue(inputElement, value) {
        if (!inputElement) return;
        
        // 1. Establecer el valor nativamente
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
        if (nativeInputValueSetter) {
            nativeInputValueSetter.call(inputElement, value);
        } else {
            inputElement.value = value;
        }
        
        // 2. Disparar eventos para que React y jQuery (WooCommerce clásico) se enteren
        inputElement.dispatchEvent(new Event('input', { bubbles: true }));
        inputElement.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Usar "Event Delegation" para escuchar el input, ya que el Block Checkout recarga el DOM dinámicamente
    document.body.addEventListener('input', function(e) {
        const target = e.target;
        if (!target || !target.tagName || target.tagName !== 'INPUT') return;
        
        // Buscar el label asociado al input (especialmente útil en el Block Checkout moderno)
        const labelEl = target.closest('div')?.querySelector('label');
        const labelText = labelEl ? labelEl.textContent.toLowerCase() : '';

        // Identificar si lo que se está escribiendo es el campo de Empresa o CIF
        const isCompanyField = target.id === 'billing_nif' 
                            || target.id === 'billing_vat' 
                            || target.id === 'billing_company'
                            || target.name === 'billing_company'
                            || (target.id && target.id.toLowerCase().includes('company'))
                            || labelText.includes('company')
                            || labelText.includes('empresa')
                            || labelText.includes('cif')
                            || labelText.includes('nif');

        if (!isCompanyField) return;

        clearTimeout(typingTimer);
        const val = target.value.trim();
        
        // Ejecutar búsqueda solo si tiene pinta de CIF/NIF (alfanumérico, sin espacios, 8-10 caracteres)
        // Esto evita que al autocompletar el "Nombre de la Empresa" (que tiene espacios) se lance otra petición
        const looksLikeCif = /^[a-zA-Z0-9]{8,10}$/.test(val);
        
        if (looksLikeCif) {
            typingTimer = setTimeout(() => searchCompany(val, target), doneTypingInterval);
        }
    });

    function searchCompany(query, triggerInput) {
        if (!apiempresasSettings || !apiempresasSettings.apiKey) {
            console.error("APIEmpresas: API Key no configurada.");
            return;
        }

        fetch(apiempresasSettings.apiUrl + encodeURIComponent(query), {
            headers: {
                'Authorization': 'Bearer ' + apiempresasSettings.apiKey,
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.name) {
                const emp = data.data;
                
                // 1. Reemplazar el CIF por el Nombre de la Empresa en el mismo campo
                if (!triggerInput.value || triggerInput.value.includes(query)) {
                    setReactInputValue(triggerInput, emp.name);
                }

                // 2. Autocompletar Dirección
                const address1 = document.getElementById('billing_address_1') || document.querySelector('input[id*="address-1"]') || document.querySelector('input[name="billing_address_1"]');
                if (address1 && emp.address) {
                    setReactInputValue(address1, emp.address);
                }

                // 3. Autocompletar Ciudad
                const city = document.getElementById('billing_city') || document.querySelector('input[id*="city"]') || document.querySelector('input[name="billing_city"]');
                if (city && emp.municipality) {
                    setReactInputValue(city, emp.municipality);
                }
                
                // 4. Autocompletar Provincia / Código Postal
                const postcode = document.getElementById('billing_postcode') || document.querySelector('input[id*="postcode"]') || document.querySelector('input[name="billing_postcode"]');
                if (postcode && emp.address) {
                    // Si la API devuelve código postal en una futura versión se mapeará.
                    // Actualmente el JSON de ejemplo no tiene zipcode aislado, pero lo dejamos preparado
                    if (emp.zipcode) {
                        setReactInputValue(postcode, emp.zipcode);
                    }
                }
            }
        })
        .catch(err => {
            console.error('APIEmpresas Error:', err);
        });
    }
});
