<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_plugin_page']);
        add_action('admin_init', [$this, 'page_init']);
    }

    public function add_plugin_page() {
        // Añadir como item de menú principal
        add_menu_page(
            'Configuración APIEmpresas', 
            'APIEmpresas', 
            'manage_options', 
            'apiempresas-settings', 
            [$this, 'create_admin_page'],
            'dashicons-building', // Icono de edificio/empresa
            30 // Posición en el menú
        );
    }

    public function create_admin_page() {
        // Encolar estilos premium para la pantalla de admin
        ?>
        <style>
            .apiempresas-admin-wrap {
                max-width: 800px;
                margin: 40px auto;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
                color: #1e293b;
            }
            .apiempresas-header {
                display: flex;
                align-items: center;
                gap: 20px;
                margin-bottom: 30px;
            }
            .apiempresas-header-icon {
                background: #0ea5e9;
                color: white;
                width: 60px;
                height: 60px;
                border-radius: 12px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 32px;
                box-shadow: 0 10px 15px -3px rgba(14, 165, 233, 0.3);
            }
            .apiempresas-header-title h1 {
                margin: 0;
                font-size: 28px;
                font-weight: 700;
                color: #0f172a;
            }
            .apiempresas-header-title p {
                margin: 5px 0 0;
                color: #64748b;
                font-size: 16px;
            }
            .apiempresas-card {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                padding: 30px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
                margin-bottom: 24px;
            }
            .apiempresas-card h2 {
                margin-top: 0;
                font-size: 20px;
                color: #0f172a;
                border-bottom: 1px solid #f1f5f9;
                padding-bottom: 15px;
                margin-bottom: 20px;
            }
            .apiempresas-input-group {
                margin-bottom: 20px;
            }
            .apiempresas-input-group label {
                display: block;
                font-weight: 600;
                margin-bottom: 8px;
                color: #334155;
            }
            .apiempresas-input-group input[type="password"] {
                width: 100%;
                max-width: 500px;
                padding: 12px 16px;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                font-size: 16px;
                transition: border-color 0.2s, box-shadow 0.2s;
            }
            .apiempresas-input-group input[type="password"]:focus {
                border-color: #0ea5e9;
                box-shadow: 0 0 0 3px rgba(14, 165, 233, 0.2);
                outline: none;
            }
            .apiempresas-desc {
                margin-top: 10px;
                font-size: 14px;
                color: #64748b;
            }
            .apiempresas-btn-primary {
                background: #0ea5e9;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 600;
                cursor: pointer;
                transition: background-color 0.2s, transform 0.1s;
                display: inline-block;
                text-decoration: none;
            }
            .apiempresas-btn-primary:hover {
                background: #0284c7;
                color: white;
                transform: translateY(-1px);
            }
            .apiempresas-features {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-top: 10px;
            }
            .apiempresas-feature-box {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                padding: 20px;
            }
            .apiempresas-feature-box h3 {
                margin-top: 0;
                font-size: 16px;
                color: #0f172a;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .apiempresas-feature-box code {
                background: #e2e8f0;
                padding: 4px 8px;
                border-radius: 6px;
                color: #0f172a;
                font-weight: 600;
            }
        </style>

        <div class="apiempresas-admin-wrap">
            <div class="apiempresas-header">
                <div class="apiempresas-header-icon">
                    <span class="dashicons dashicons-building" style="font-size: 32px; width: 32px; height: 32px;"></span>
                </div>
                <div class="apiempresas-header-title">
                    <h1>APIEmpresas B2B Suite</h1>
                    <p>Potencia tu WordPress con datos mercantiles oficiales de España</p>
                </div>
            </div>

            <?php if (isset($_GET['settings-updated'])) : ?>
                <div class="updated notice is-dismissible" style="border-left-color: #10b981;">
                    <p><strong>Ajustes guardados correctamente.</strong> ¡Tu web ya está conectada con APIEmpresas!</p>
                </div>
            <?php endif; ?>

            <div class="apiempresas-card">
                <h2>Configuración de Conexión</h2>
                <form method="post" action="options.php">
                    <?php settings_fields('apiempresas_option_group'); ?>
                    
                    <div class="apiempresas-input-group">
                        <label for="apiempresas_api_key">Clave de API (API Key Secreta)</label>
                        <?php $apiKey = get_option('apiempresas_api_key'); ?>
                        <input type="password" id="apiempresas_api_key" name="apiempresas_api_key" value="<?php echo esc_attr($apiKey); ?>" placeholder="sk_live_..." />
                        <p class="apiempresas-desc">
                            Obtén tu API Key gratuita registrándote en <a href="https://apiempresas.es/register" target="_blank" style="color: #0ea5e9; font-weight: 600; text-decoration: none;">APIEmpresas.es</a>.
                        </p>
                    </div>

                    <button type="submit" class="apiempresas-btn-primary">Conectar y Guardar Cambios</button>
                </form>
            </div>

            <div class="apiempresas-card">
                <h2>Funcionalidades Activas</h2>
                <div class="apiempresas-features">
                    <div class="apiempresas-feature-box">
                        <h3><span class="dashicons dashicons-search"></span> Buscador B2B</h3>
                        <p>Pega el shortcode <code>[apiempresas_buscador]</code> en cualquier página para ofrecer un buscador inteligente de empresas a tus visitantes.</p>
                    </div>
                    <div class="apiempresas-feature-box">
                        <h3><span class="dashicons dashicons-cart"></span> Auto-Checkout (WooCommerce)</h3>
                        <p>Si tienes WooCommerce instalado, el plugin se ha integrado automáticamente. Cuando un cliente escriba su CIF en el checkout, la Razón Social y Dirección se autocompletarán solas.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function page_init() {
        register_setting(
            'apiempresas_option_group',
            'apiempresas_api_key',
            ['sanitize_callback' => 'sanitize_text_field']
        );
    }
}
