<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_WooCommerce {

    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_script']);
    }

    public function enqueue_checkout_script() {
        // Solo cargar en la página de checkout
        if (!is_checkout()) {
            return;
        }

        $apiKey = get_option('apiempresas_api_key');
        if (empty($apiKey)) {
            return;
        }

        wp_enqueue_script('apiempresas-woo-js', APIEMPRESAS_PLUGIN_URL . 'assets/js/checkout.js', [], '1.0.0', true);
        
        // Apuntar a localhost para pruebas en entorno local sin tener que subir a producción
        $apiUrl = 'http://localhost/apiempresas/api/v1/companies?cif=';

        wp_localize_script('apiempresas-woo-js', 'apiempresasSettings', [
            'apiKey' => $apiKey,
            'apiUrl' => $apiUrl
        ]);
    }
}
