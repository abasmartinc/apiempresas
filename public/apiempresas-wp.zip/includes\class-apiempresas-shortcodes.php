<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_Shortcodes {

    public function __construct() {
        add_shortcode('apiempresas_buscador', [$this, 'render_search_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets() {
        wp_register_style('apiempresas-css', APIEMPRESAS_PLUGIN_URL . 'assets/css/style.css', [], '1.0.0');
    }

    public function render_search_shortcode($atts) {
        wp_enqueue_style('apiempresas-css');
        
        $apiKey = get_option('apiempresas_api_key');
        if (empty($apiKey)) {
            return '<p style="color:red; font-weight:bold;">Error: No has configurado la API Key de APIEmpresas en los ajustes del plugin.</p>';
        }

        ob_start();
        ?>
        <div class="apiempresas-search-widget">
            <div class="apiempresas-search-header">
                <span class="apiempresas-search-icon">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </span>
                <h3 class="apiempresas-title">Buscar Empresa por CIF</h3>
            </div>
            <p class="apiempresas-subtitle">Obtén datos verificados al instante.</p>
            <div class="apiempresas-search-bar">
                <div class="apiempresas-input-wrapper">
                    <svg class="apiempresas-input-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2"></path></svg>
                    <input type="text" id="apiempresas-search-input" placeholder="Introduce el CIF. Ej: B46401659" />
                </div>
                <button type="button" id="apiempresas-search-btn">Consultar</button>
            </div>
            <div id="apiempresas-results" class="apiempresas-results"></div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const searchBtn = document.getElementById('apiempresas-search-btn');
                const searchInput = document.getElementById('apiempresas-search-input');
                const resultsDiv = document.getElementById('apiempresas-results');

                searchBtn.addEventListener('click', function() {
                    const query = searchInput.value.trim();
                    if(!query) return;

                    resultsDiv.innerHTML = '<p class="apiempresas-loading"><svg style="animation: apiPulse 1s linear infinite; width:24px; height:24px;" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg> Buscando...</p>';

                    fetch('http://localhost/apiempresas/api/v1/companies/search?multiple=true&q=' + encodeURIComponent(query), {
                        headers: {
                            'Authorization': 'Bearer <?php echo esc_js($apiKey); ?>',
                            'Accept': 'application/json'
                        }
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('Error en la API');
                        return response.json();
                    })
                    .then(data => {
                        // Data.data is an array when multiple=true
                        if (data.data && Array.isArray(data.data) && data.data.length > 0) {
                            let html = '<div class="apiempresas-list">';
                            data.data.forEach(empresa => {
                                const addressStr = `${empresa.address || ''}, ${empresa.zipcode || ''} ${empresa.city || ''} (${empresa.province || ''})`.replace(/^, | \(\)/g, '').trim();
                                html += `
                                <div class="apiempresas-card">
                                    <div class="apiempresas-card-header">
                                        <h4>${empresa.name}</h4>
                                        <span class="apiempresas-cif">${empresa.cif}</span>
                                    </div>
                                    <div class="apiempresas-card-body">
                                        ${empresa.status ? '<div class="api-data-row"><strong>Estado:</strong> <span>' + empresa.status + '</span></div>' : ''}
                                        ${empresa.cnae_label ? '<div class="api-data-row"><strong>Sector:</strong> <span>' + empresa.cnae_label + '</span></div>' : ''}
                                        ${addressStr && addressStr.length > 3 ? '<div class="api-data-row" style="grid-column: 1 / -1;"><strong>Dirección:</strong> <span>' + addressStr + '</span></div>' : ''}
                                        ${empresa.incorporation_date ? '<div class="api-data-row"><strong>Fecha Const.:</strong> <span>' + empresa.incorporation_date + '</span></div>' : ''}
                                        ${empresa.capital ? '<div class="api-data-row"><strong>Capital Social:</strong> <span>' + empresa.capital + '</span></div>' : ''}
                                        ${empresa.employees ? '<div class="api-data-row"><strong>Empleados:</strong> <span>' + empresa.employees + '</span></div>' : ''}
                                    </div>
                                </div>
                                `;
                            });
                            html += '</div>';
                            resultsDiv.innerHTML = html;
                        } else {
                            resultsDiv.innerHTML = '<p>No se encontraron resultados.</p>';
                        }
                    })
                    .catch(err => {
                        resultsDiv.innerHTML = '<p style="color:red;">Ocurrió un error o la API Key no es válida.</p>';
                    });
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }
}
