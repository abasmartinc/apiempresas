<?php
if (!defined('ABSPATH')) {
    exit;
}

class APIEmpresas_Shortcodes {

    public function __construct() {
        add_shortcode('apiempresas_buscador', [$this, 'render_search_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function enqueue_assets() {
        wp_register_style('apiempresas-css', APIEMPRESAS_PLUGIN_URL . 'assets/css/style.css', [], '1.0.0');
    }

    public function render_search_shortcode($atts) {
        wp_enqueue_style('apiempresas-css');
        
        $apiKey = get_option('apiempresas_api_key');
        if (empty($apiKey)) {
            return '<p style="color:red; font-weight:bold;">Error: No has configurado la API Key de APIEmpresas en los ajustes del plugin.</p>';
        }

        ob_start();
        ?>
        <div class="apiempresas-search-widget">
            <h3 class="apiempresas-title">Verificar Empresa o CIF</h3>
            <div class="apiempresas-search-bar">
                <input type="text" id="apiempresas-search-input" placeholder="Ej: Mercadona o B46401659" />
                <button type="button" id="apiempresas-search-btn">Buscar</button>
            </div>
            <div id="apiempresas-results" class="apiempresas-results"></div>
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const searchBtn = document.getElementById('apiempresas-search-btn');
                const searchInput = document.getElementById('apiempresas-search-input');
                const resultsDiv = document.getElementById('apiempresas-results');

                searchBtn.addEventListener('click', function() {
                    const query = searchInput.value.trim();
                    if(!query) return;

                    resultsDiv.innerHTML = '<p class="apiempresas-loading">Buscando en APIEmpresas.es...</p>';

                    fetch('https://apiempresas.es/api/search?q=' + encodeURIComponent(query), {
                        headers: {
                            'Authorization': 'Bearer <?php echo esc_js($apiKey); ?>',
                            'Accept': 'application/json'
                        }
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('Error en la API');
                        return response.json();
                    })
                    .then(data => {
                        if (data.data && data.data.length > 0) {
                            let html = '<div class="apiempresas-list">';
                            data.data.forEach(empresa => {
                                html += `
                                <div class="apiempresas-card">
                                    <div class="apiempresas-card-header">
                                        <h4>${empresa.name}</h4>
                                        <span class="apiempresas-cif">${empresa.cif}</span>
                                    </div>
                                    <p>${empresa.province || 'España'} - Estado: <strong>${empresa.status}</strong></p>
                                </div>
                                `;
                            });
                            html += '</div>';
                            resultsDiv.innerHTML = html;
                        } else {
                            resultsDiv.innerHTML = '<p>No se encontraron resultados.</p>';
                        }
                    })
                    .catch(err => {
                        resultsDiv.innerHTML = '<p style="color:red;">Ocurrió un error o la API Key no es válida.</p>';
                    });
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }
}
